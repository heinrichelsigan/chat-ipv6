package org.bouncycastle.pqc.crypto.test;

class TestUtils
{
    static boolean parseBoolean(String value)
    {
        return "true".equalsIgnoreCase(value);
    }
}
