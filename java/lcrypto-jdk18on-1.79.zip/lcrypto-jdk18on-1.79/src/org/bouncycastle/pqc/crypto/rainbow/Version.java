package org.bouncycastle.pqc.crypto.rainbow;

enum Version
{
    CLASSIC,
    CIRCUMZENITHAL,
    COMPRESSED
}
