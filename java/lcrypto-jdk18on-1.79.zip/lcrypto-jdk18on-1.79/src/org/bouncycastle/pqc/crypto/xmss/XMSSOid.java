package org.bouncycastle.pqc.crypto.xmss;

public interface XMSSOid
{

    int getOid();

    String toString();
}
