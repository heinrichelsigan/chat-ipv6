package org.bouncycastle.pqc.crypto;

import org.bouncycastle.crypto.CipherParameters;

public interface KEMParameters
    extends CipherParameters
{
}
