package org.bouncycastle.pqc.crypto.falcon;

class FalconSmallPrime
{
    int p;
    int g;
    int s;

    FalconSmallPrime(int p, int g, int s)
    {
        this.p = p;
        this.g = g;
        this.s = s;
    }
}
