package org.bouncycastle.pqc.crypto.falcon;

class FalconFPR
{
    double v;

    FalconFPR(double v)
    {
        this.v = v;
    }
}
